# Aether App (Windows first)

Flutter GUI around the official Aether core (https://github.com/CluvexStudio/Aether).
Untested scaffold: I could not compile or run it where it was written.

## Run on Windows
1. Install Flutter and Visual Studio (Desktop development with C++).
2. In this folder run: `flutter create --platforms=windows .`
3. Download the Windows build of Aether from the official releases, and verify it
   with the .sha256 file. Put `aether.exe` and its `pt/` folder next to the built app
   (`build\windows\x64\runner\Release\`).
4. `flutter run -d windows`, or `flutter build windows`.

The app starts the core with the chosen flag (--masque, --gool, --psiphon, --tor)
plus --stats, waits for SOCKS5 on 127.0.0.1:1819, then sets the Windows user
proxy (socks=127.0.0.1:1819). Disconnect clears it.

## Android (not included)
Needs a VpnService that feeds a TUN into the core's SOCKS5 port with
hev-socks5-tunnel, and the core built for Android. The open source 8 VPN project
(Mrmmd2004/8vpn) is a working reference for that part.

## License
Aether is AGPL-3.0 and its trademark policy asks derivative apps to use their own
name. Pick your own app name and credit the core.
