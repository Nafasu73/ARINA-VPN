import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/foundation.dart';

enum Conn { off, connecting, on }

/// Transports taken from the Aether v2.3.0 release notes.
const modes = <String, List<String>>{
  'MASQUE': ['--masque'],
  'Gool': ['--gool'],
  'Psiphon': ['--psiphon'],
  'Tor': ['--tor'],
};

const socksPort = 1819; // Aether default local SOCKS5 port

class AetherCore extends ChangeNotifier {
  Conn state = Conn.off;
  final logs = <String>[];
  Process? _p;
  Timer? _tick;
  DateTime? _since;
  String get uptime {
    if (_since == null) return '00:00';
    final s = DateTime.now().difference(_since!).inSeconds;
    return '${(s ~/ 60).toString().padLeft(2, '0')}:${(s % 60).toString().padLeft(2, '0')}';
  }

  /// aether.exe must sit next to the app executable (download it from the
  /// official CluvexStudio/Aether releases and keep its pt/ folder beside it).
  String get corePath {
    final dir = File(Platform.resolvedExecutable).parent.path;
    return Platform.isWindows ? '$dir\\aether.exe' : '$dir/aether';
  }

  void _log(String l) {
    logs.add(l);
    if (logs.length > 300) logs.removeAt(0);
    notifyListeners();
  }

  Future<void> start({
    required String mode,
    String? psiphonRegion,
    String? exitLoc,
    bool systemProxy = true,
  }) async {
    if (state != Conn.off) return;
    if (!File(corePath).existsSync()) {
      _log('Core not found: $corePath');
      return;
    }
    state = Conn.connecting;
    notifyListeners();
    final args = [...modes[mode]!, '--stats'];
    if (mode == 'Psiphon' && psiphonRegion != null && psiphonRegion.isNotEmpty) {
      args.addAll(['--psiphon-region', psiphonRegion]);
    }
    if (exitLoc != null && exitLoc.isNotEmpty) args.addAll(['--exit-loc', exitLoc]);
    _log('> aether ${args.join(' ')}');
    try {
      _p = await Process.start(corePath, args,
          workingDirectory: File(corePath).parent.path);
    } catch (e) {
      _log('Failed to start: $e');
      state = Conn.off;
      notifyListeners();
      return;
    }
    for (final s in [_p!.stdout, _p!.stderr]) {
      s.transform(utf8.decoder).transform(const LineSplitter()).listen(_log);
    }
    _p!.exitCode.then((c) {
      _log('Core exited ($c)');
      _cleanup();
    });
    // SOCKS5 opens only after the tunnel is verified, so wait for the port.
    final end = DateTime.now().add(const Duration(seconds: 90));
    while (DateTime.now().isBefore(end) && state == Conn.connecting) {
      try {
        final s = await Socket.connect('127.0.0.1', socksPort,
            timeout: const Duration(milliseconds: 400));
        s.destroy();
        state = Conn.on;
        _since = DateTime.now();
        _tick = Timer.periodic(const Duration(seconds: 1), (_) => notifyListeners());
        if (systemProxy) await _setSystemProxy(true);
        _log('Connected. SOCKS5 on 127.0.0.1:$socksPort');
        notifyListeners();
        return;
      } catch (_) {
        await Future.delayed(const Duration(milliseconds: 500));
      }
    }
    if (state == Conn.connecting) {
      _log('Timed out waiting for the tunnel.');
      await stop();
    }
  }

  Future<void> stop() async {
    _p?.kill();
    await _cleanup();
  }

  Future<void> _cleanup() async {
    _tick?.cancel();
    _since = null;
    _p = null;
    await _setSystemProxy(false);
    state = Conn.off;
    notifyListeners();
  }

  /// Windows only: sets or clears the per-user SOCKS system proxy.
  Future<void> _setSystemProxy(bool on) async {
    if (!Platform.isWindows) return;
    const key = r'HKCU\Software\Microsoft\Windows\CurrentVersion\Internet Settings';
    Future<void> reg(List<String> a) => Process.run('reg', ['add', key, '/f', ...a]);
    if (on) {
      await reg(['/v', 'ProxyServer', '/t', 'REG_SZ', '/d', 'socks=127.0.0.1:$socksPort']);
      await reg(['/v', 'ProxyEnable', '/t', 'REG_DWORD', '/d', '1']);
    } else {
      await reg(['/v', 'ProxyEnable', '/t', 'REG_DWORD', '/d', '0']);
    }
  }
}
