import 'package:flutter/material.dart';
import 'core.dart';

void main() => runApp(const App());

const bg = Color(0xFF07061A), panel = Color(0xFF100E2B), line = Color(0xFF26224F);
const violet = Color(0xFF8B5CFF), cyan = Color(0xFF22E5FF), ok = Color(0xFF3DFFB0);

class App extends StatelessWidget {
  const App({super.key});
  @override
  Widget build(BuildContext c) => MaterialApp(
        debugShowCheckedModeBanner: false,
        theme: ThemeData.dark(useMaterial3: true).copyWith(scaffoldBackgroundColor: bg),
        home: const Directionality(textDirection: TextDirection.rtl, child: Home()),
      );
}

class Home extends StatefulWidget {
  const Home({super.key});
  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  final core = AetherCore();
  String mode = 'MASQUE';
  bool sysProxy = true;
  final region = TextEditingController(text: 'DE');
  final exitLoc = TextEditingController();

  @override
  void initState() {
    super.initState();
    core.addListener(() => setState(() {}));
  }

  @override
  void dispose() {
    core.stop();
    super.dispose();
  }

  void toggle() {
    if (core.state == Conn.off) {
      core.start(
          mode: mode,
          psiphonRegion: region.text.trim(),
          exitLoc: exitLoc.text.trim(),
          systemProxy: sysProxy);
    } else {
      core.stop();
    }
  }

  @override
  Widget build(BuildContext context) {
    final on = core.state == Conn.on, busy = core.state == Conn.connecting;
    final label = on ? 'قطع' : busy ? '…' : 'اتصال';
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 460),
            child: ListView(padding: const EdgeInsets.all(20), children: [
              const Text('Aether', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
              const SizedBox(height: 24),
              Center(
                child: GestureDetector(
                  onTap: busy ? null : toggle,
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 300),
                    width: 160, height: 160,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: panel,
                      border: Border.all(color: on ? ok : violet, width: 4),
                      boxShadow: [BoxShadow(color: (on ? ok : violet).withOpacity(.5), blurRadius: 60)],
                    ),
                    child: Center(
                      child: busy
                          ? const CircularProgressIndicator(color: cyan)
                          : Text(label, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 18),
              Center(
                child: Text(on ? 'متصل · ${core.uptime}' : busy ? 'در حال اتصال…' : 'قطع است',
                    style: const TextStyle(fontWeight: FontWeight.w600)),
              ),
              const SizedBox(height: 22),
              _card(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('روش اتصال'),
                const SizedBox(height: 10),
                SegmentedButton<String>(
                  segments: [for (final m in modes.keys) ButtonSegment(value: m, label: Text(m))],
                  selected: {mode},
                  onSelectionChanged: core.state == Conn.off ? (s) => setState(() => mode = s.first) : null,
                ),
                if (mode == 'Psiphon') ...[
                  const SizedBox(height: 12),
                  TextField(controller: region, decoration: const InputDecoration(labelText: 'کشور خروجی (مثلا DE)')),
                ],
                const SizedBox(height: 12),
                TextField(
                    controller: exitLoc,
                    decoration: const InputDecoration(
                        labelText: 'فیلتر کشور خروجی (مثلا !IR,RU یا DE,SE)')),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('تنظیم خودکار پروکسی ویندوز'),
                  value: sysProxy,
                  onChanged: core.state == Conn.off ? (v) => setState(() => sysProxy = v) : null,
                ),
              ])),
              const SizedBox(height: 14),
              _card(SizedBox(
                height: 180,
                child: ListView(
                  reverse: true,
                  children: [
                    for (final l in core.logs.reversed)
                      Text(l, textDirection: TextDirection.ltr,
                          style: const TextStyle(fontFamily: 'Consolas', fontSize: 11, color: Color(0xFF8D89BD)))
                  ],
                ),
              )),
            ]),
          ),
        ),
      ),
    );
  }

  Widget _card(Widget child) => Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
            color: panel, borderRadius: BorderRadius.circular(18), border: Border.all(color: line)),
        child: child,
      );
}
